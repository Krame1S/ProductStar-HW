class Pet:
    def __init__(self, name, species, age, gender):
        self.__name = name
        self.__species = species
        self.__age = age
        self.__gender = gender

    def get_info(self):
        return f"Имя: {self.__name}, Вид: {self.__species}, Возраст: {self.__age}, Пол: {self.__gender}"

class Dog(Pet):
    def __init__(self, name, age, gender, breed):
        super().__init__(name, "Собака", age, gender)
        self.__breed = breed

    def bark(self):
        return "Гав!"

class Cat(Pet):
    def __init__(self, name, age, gender, color):
        super().__init__(name, "Кошка", age, gender)
        self.__color = color

    def meow(self):
        return "Мяу!"

dog = Dog("Барсик", 3, "Мужской", "Лабрадор")
cat = Cat("Марго", 2, "Женский", "Серый")
print(dog.get_info())
print(cat.get_info())
print(dog.bark())
print(cat.meow())
